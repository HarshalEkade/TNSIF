package com.playerinfo;

import com.playerinfo.view.LoginPage;
import javafx.application.Application;
public class Main {
public static void main(String[] args) {
System.out.println("Launching Players Info ......");
Application.launch(LoginPage.class,args);
}
}